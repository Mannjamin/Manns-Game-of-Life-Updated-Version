package init;

import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JFrame;
import gui.golGUI;

public class golInit
{
	public static JFrame game;	
	//Main Frame Settings.	
	public static void main(String[] args) 
	{
		//Declare Frame.
		game = new golGUI();
		//Border-less Frame
		game.setUndecorated(true);
		//Stop Operation on Close.
		game.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//Set Frame Title.
		game.setTitle("Mann's Game Of Life");
		//Set Frame Size.
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		game.setBounds(200, 100, screenSize.width, screenSize.height);
		//Set Frame Position.
		game.setLocationRelativeTo(null);
		//Set Frame Visibility.
		game.setVisible(true);
	}//End of main. DO NOT TOUCH
}