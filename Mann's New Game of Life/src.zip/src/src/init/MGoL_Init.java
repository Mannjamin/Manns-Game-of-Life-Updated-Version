package src.init;

//import java.awt.Dimension;
//import java.awt.Toolkit;
import javax.swing.JFrame;
import src.gui.MGoL_GUI;

public class MGoL_Init
{
	public static JFrame game;	
	
	//Main Frame Settings.	
	public static void main(String[] args) 
	{
		//Declare Frame.
		game = new MGoL_GUI();
		//Border-less Frame
		game.setUndecorated(false);
		//Stop Operation on Close.
		game.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//Set Frame Title.
		game.setTitle("Mann's Game Of Life");
		//Set Frame Size.
		//Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		game.setBounds(200, 100, 1600/*screenSize.width*/, 900/*screenSize.height*/);
		//Set Frame Position.
		game.setLocationRelativeTo(null);
		//Set Frame Visibility.
		game.setVisible(true);
	}//End of main. DO NOT TOUCH

	protected void setVisible(boolean b) {}
}