package src.backend;

import java.awt.Color;
import java.awt.Dimension;
//import java.awt.Font;
import java.awt.Graphics;
//import java.awt.Graphics2D;
import java.awt.Point;
//import java.awt.RenderingHints;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
//import java.awt.image.BufferedImage;
//import java.io.File;
//import java.io.IOException;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.EventObject;

//import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
//import javax.swing.JSlider;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import src.gui.MGoL_GUI;

public class MGoL_Backend extends JPanel implements ComponentListener, MouseListener, MouseMotionListener, Runnable, ChangeListener
{
	//This class contains most Game of Life Components including the main board, the human interaction features and more. 
	//Generic Serial Version ID.
	private static final long serialVersionUID = 882831296469793120L;
	
	
	public static Color cellColor;
	public static Graphics g;
	
	//Cell Size
	public static int cellSize = 20;


	public static Object outsideOfUniverse;


	public static Object alive;
	
	//Defines the Dimensions of the Game of Life Board. This is defined further down. 
	public Dimension GameOfLifeDimensions = new Dimension(getWidth()/cellSize-2, getHeight()/cellSize-2);
	
	public static ArrayList<Point> point = new ArrayList<Point>(0);
	
	public MGoL_Backend() 
	{
		//Game Of Life Constructor.
		//This Constructor inherits the Game Of Life Parameters. 
		//This is the first method which is initiated when the game of life is run.
		//Style Game of Life Board
		setBackground(Color.black);		//Make background of the Game Of Life black.
		addComponentListener(this);		//Calls the addComponentListenerMethod. Without this, the Game Of Life will not compile.
		addMouseListener(this);			//Calls the addMouseListener. Without this, the user cannot interact with the gameboard.
		addMouseMotionListener(this);	//Calls the addMouseMotionListener. Without this, the user cannot create a path with the mouse.
		
		
	}
	//End of GameOfLifeBoard. DO NOT TOUCH.
	
	//##############################################################################################################################################

	public void addPoint(int x, int y, MouseEvent me, boolean[][] glider, boolean[][] spaceship) 
	{
		SwingUtilities.isLeftMouseButton(me);
		SwingUtilities.isRightMouseButton(me);
		if(MGoL_GUI.isGlider)
		{	//if isGlider Boolean is true. The following array will generate at the Point of mouse click. 
			//This Array will print out the Boolean Gun based on the pre-written 9 x 36 array manually written within the Action Events method.
			for(int i=0; i < 9; ++i)     
			{  										
				for(int j=0; j < 36; ++j)
				{
					//Prints out the array at the mouse press point.
					if(glider[i][j]) { point.add(new Point(x+i, y+j)); }
				}		
			}
		}
		else if(MGoL_GUI.isSpaceship)
		{	//if isSpaceship Boolean is true. The following array will generate at the Point of mouse click. 
			//This Array will print out the Boolean ship based on the pre-written 5 x 4  array manually written within the Action Events method.
			for(int k=0; k < 4; ++k)
			{
				for(int l=0; l < 5; ++l)
				{
					//Prints out the array at the mouse press point.
					if(spaceship[k][l]) { point.add(new Point(x+k, y+l)); }
				}		
			}
		}
		//If Left Mouse Button is pressed on the mouse.
		else if (SwingUtilities.isLeftMouseButton(me)) { point.add(new Point(x,y)); } //Add Point at Mouse Press 
		else if (SwingUtilities.isRightMouseButton(me)) //If Right Mouse Button is pressed on the mouse.
		{
			point.remove(new Point(x,y));//Add Point at Mouse Press
			++MGoL_GUI.deadCount;
			--MGoL_GUI.survivorCount;
		}	  	
		repaint();
	} //End of AddPoint

	//##############################################################################################################################################
	
	public void addPoint(MouseEvent me, boolean[][] glider, boolean[][] spaceship) 
	{
		int x = me.getPoint().x/cellSize-1; //Coordinate of X-axis on Mouse Press
		int y = me.getPoint().y/cellSize-1; //Coordinate of Y-axis on Mouse press
		if ((x >= 0) && (x < GameOfLifeDimensions.width) && (y >= 0) && (y < GameOfLifeDimensions.height))
		{
			addPoint(x,y,me,glider,spaceship);
		}
	}//End of AddPoint
	
	//##############################################################################################################################################
	// Updates the component on which the universe is located.
	public void updateUniverseSize()
	{
		ArrayList<Point> outsideOfUniverse = new ArrayList<Point>(0);
		for (Point alive : point)
		{
			if ( (alive.x > GameOfLifeDimensions.width - 1) || (alive.y > GameOfLifeDimensions.height - 1) )
			{
				outsideOfUniverse.add(alive);
			}
		}
		point.removeAll(outsideOfUniverse);
		repaint();
	}
	//##############################################################################################################################################
	
	public void resetBoard()
	{
		point.clear();			//Remove all points (Alive Cells) from the board.
		repaint();				//Refresh the board.
	}
	
	//##############################################################################################################################################

	public void artBoard()
	{
		//Gif
		//Creates image as a new Buffered Image.
		//144,32 are the dimensions of the Image.
		//TYPE_INT_RGB is the type of buffered image.
		//This code was discovered online and edited for compatibility with my code. below is the harvard reference:
		//Ascii Art - Java
		//In-text: ([Ascii Art - Java, 2017)
		//Ascii Art - Java. [online] Stackoverflow.com. Available at: http://stackoverflow.com/questions/7098972/ascii-art-java [Accessed 6 Mar. 2017].
		//BufferedImage image = new BufferedImage(144, 32, BufferedImage.TYPE_INT_RGB);
		//Graphics g = image.getGraphics();
		////Font of output ASCII ART.
		//g.setFont(new Font("Comic Sans MS", Font.BOLD, 24));
		//Graphics2D graphics = (Graphics2D) g;
		//graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		////the Image reading.
		//graphics.drawString("I love Java", 6, 24);
		//try { ImageIO.write(image, "gif", new File("java.gif")); } 
		//catch (IOException e) { JOptionPane.showMessageDialog(null, "An Error Has Occured. Please Restart the Code."); }
		//boolean[][] gifArray = new boolean[32][144];
		//for (int y = 0 ; y < 32 ; y++) 
		//{
		//	for (int x = 0; x < 144; x++)
		//	{
		//		gifArray[y][x] = (image.getRGB(x, y) == -16777216 ? true : image.getRGB(x, y) == -1 ? false : false);
		//		// If this is the starting grid configuration, then do the below as well
		//		if (gifArray[y][x]) { point.add(new Point(x+25, y+20)); }
		//	} 
		//}
	}
	
	//##############################################################################################################################################

	public void randomFill(int percent)  //If Method is called, randomly fill the board with points.
	{		
		for (int i=0; i<GameOfLifeDimensions.width; i++) 
		{
			for (int j=0; j<GameOfLifeDimensions.height; j++) 
			{
				if (Math.random()*100 < percent) { point.add(new Point(i,j)); }
			}
		}
	}

	//##############################################################################################################################################
	
	@Override
	public void paintComponent(Graphics g) 
	{
		super.paintComponent(g);
		try 
		{	

			// Setup grid
			g.setColor(cellColor);
			repaint();
			
			for (Point newPoint : point) 
			{
				if(MGoL_GUI.squareCell){
					MGoL_GUI.squareCellCheck.setSelected(true);
					MGoL_GUI.circularCellCheck.setSelected(false);
					
					g.fillRect(cellSize + (cellSize*newPoint.x), cellSize + (cellSize*newPoint.y), cellSize, cellSize);
				} else {
					MGoL_GUI.squareCellCheck.setSelected(false);
					MGoL_GUI.circularCellCheck.setSelected(true);
					
					g.fillOval(cellSize + (cellSize*newPoint.x), cellSize + (cellSize*newPoint.y), cellSize, cellSize);

				}
			}
		} 
		
		catch (ConcurrentModificationException cme) {} //
		
		// Setup grid
		if (MGoL_GUI.gridVisible) { g.setColor(Color.gray); repaint(); }
		else { g.setColor(Color.black); repaint();}
		repaint();
		
		//Rectangle Grid
		for (int i=0; i<=GameOfLifeDimensions.width; i++) 
		{
			g.drawLine(((i*cellSize)+cellSize), cellSize, (i*cellSize)+cellSize, cellSize + (cellSize*GameOfLifeDimensions.height) );
		}
		for (int i=0; i<=GameOfLifeDimensions.height; i++) 
		{
			g.drawLine(cellSize, ((i*cellSize)+cellSize), cellSize*(GameOfLifeDimensions.width+1), ((i*cellSize)+cellSize) );
		}
		
		updateStatisticsMenu();
	}
	//End of paintComponent
	
	//##############################################################################################################################################
	
	private void updateStatisticsMenu()
	{	
		//Asynchronously Update Statistics Menu
		MGoL_GUI.survivorCount = point.size();
		MGoL_GUI.existenceCount = point.size() + MGoL_GUI.deadCount;
		//Speed Value
		String speedOutput = String.format("%03d%n", MGoL_GUI.speed);
		MGoL_GUI.speedLabel.setText("| Speed: " + speedOutput + " G/s |");
		//Generation Values
		String generationOutput = String.format("%08d%n", MGoL_GUI.generationCount);
		//Sets Starting Value of Cells Alive Count
		MGoL_GUI.generationLabel.setText("| Generation: " + generationOutput + " |");
		//Survivor Values
		String cellOutput = String.format("%08d%n", MGoL_GUI.survivorCount);
		//Sets Starting Value of Cells Alive Count
		MGoL_GUI.survivorLabel.setText("| Cells Alive: " + cellOutput + " |");
		//Dead Values
		String deadOutput = String.format("%08d%n", MGoL_GUI.deadCount);
		//Sets Starting Value of existence Count
		MGoL_GUI.deadLabel.setText("| Cells Dead: " + deadOutput + " |");
		//Existing Values
		String existOutput = String.format("%08d%n", MGoL_GUI.existenceCount);
		//Sets Starting Value of existence Count
		MGoL_GUI.existLabel.setText("| Cells Total: " + existOutput + " |");
	}

	//##############################################################################################################################################
	
	@Override
	public void componentResized(ComponentEvent e) 
	{
		// Setup the game board size with proper boundaries
		GameOfLifeDimensions = new Dimension(getWidth()/cellSize-2, getHeight()/cellSize-2);
		updateUniverseSize();
	}
	
	
	

	//##############################################################################################################################################
	
	//DO NOT TOUCH
	@Override
	public void run() 
	{	
		boolean[][] GameOfLifeBoard = new boolean[GameOfLifeDimensions.width][GameOfLifeDimensions.height];
		try
		{
			for (Point current : point) 
			{
				GameOfLifeBoard[current.x][current.y] = true;
			}
		} 
		catch(ArrayIndexOutOfBoundsException ae) {}
		ArrayList<Point> survivingCells = new ArrayList<Point>(0);
		// Iterate through the array, follow game of life rules
		for (int i=0; i<GameOfLifeBoard.length; i++) 
		{
			for (int j=0; j<GameOfLifeBoard[0].length; j++) 
			{
				int n = wraparoundloop(GameOfLifeBoard, i, j);

				if(hopeitWorks(n, GameOfLifeBoard[i][j]))
				{
					survivingCells.add(new Point(i, j));
				}
			}
		}
		resetBoard();
		MGoL_GUI.generationCount++;
		MGoL_GUI.survivorCount = survivingCells.size();
		point.addAll(survivingCells);
		repaint();          
	}
	//End of Run. DO NOT TOUCH.
	
	//##############################################################################################################################################
	
	public int wraparoundloop(boolean[][] GameOfLifeBoard, int X, int Y)
	{
		//ternary statement
		int value = GameOfLifeBoard[X][Y] ? -1 : 0;
		int rows = GameOfLifeBoard.length;
		int columns = GameOfLifeBoard[0].length;

		for (int a = -1; a <= 1; ++a)
		{
			for(int b = -1; b <= 1; ++b)
			{
				if( GameOfLifeBoard[(rows + X + a) % rows][(columns + Y + b) % columns]){value++;}
			}
		}
		return value;
	}
	//End of Wrap around Loop. DO NOT TOUCH.
	
	//##############################################################################################################################################
	
	public boolean hopeitWorks(int n, boolean alive)
	{
		if(alive && (n == 2 || n == 3)) { return true; }
		else if(!alive && (n == 3)) { ++MGoL_GUI.deadCount; return true; }
		else return false;
	}
	//End of Hope it works. DO NOT TOUCH.
	
	//##############################################################################################################################################
	
	// Mouse was released (user clicked)
	@Override
	public void mousePressed(MouseEvent e) { addPoint(e,MGoL_GUI.glider,MGoL_GUI.spaceship); }
	// Mouse is being dragged, user wants multiple selections
	@Override
	public void mouseDragged(MouseEvent e)
	{
		try { addPoint(e,MGoL_GUI.glider,MGoL_GUI.spaceship); }
		catch(ArrayIndexOutOfBoundsException ae) { JOptionPane.showMessageDialog(null, "An array cannot be printed outside the frame."); }
	}
	//These methods are unnecessary but needed within the code for compilation.
	@Override
	public void mouseMoved(MouseEvent e) {}
	@Override
	public void mouseReleased(MouseEvent e) {}
	@Override
	public void mouseEntered(MouseEvent e) {}
	@Override
	public void mouseExited(MouseEvent e) {}
	@Override
	public void componentMoved(ComponentEvent e) {}
	@Override
	public void componentShown(ComponentEvent e) {}
	@Override
	public void componentHidden(ComponentEvent e) {}
	@Override
	public void mouseClicked(MouseEvent e) {}
	@Override
	public void stateChanged(ChangeEvent e) {}

	public void outsideOfUniverse() {
		// TODO Auto-generated method stub
		
	}



}
//End of GameOfLifeBoard. DO NOT TOUCH